import React from 'react'
import MTGenerator from './components/MTGenerator'

export default function App() {
  return (
    <div>
      <MTGenerator />
    </div>
  )
}
